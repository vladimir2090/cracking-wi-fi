Hello! This is a code for" cracking " (decoding) the Wi-Fi password. It is suitable for school computers. I hope you understand what I mean.
)))